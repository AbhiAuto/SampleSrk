package com.test.stepdefs;

import io.cucumber.java.en.Given;

public class stepdefinition {
	
	@Given("I have google application")
	public void I_have_google_application()
	{
		System.out.println("Testing");
	}
}
